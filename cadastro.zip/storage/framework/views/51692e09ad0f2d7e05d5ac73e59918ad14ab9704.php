<?php $__env->startSection('body'); ?>
<div class="card border">
    <div class="card-body">
        <form action="/produtos/<?php echo e($produt->id); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="nomeProduto">Nome do Produto</label>
                <input type="text" required class="form-control" name="nomeProduto" 
                id="nomeProduto" placeholder="Produto" value="<?php echo e($produt->nome); ?>"><br>
                <label for="estoqueProduto">Em estoque</label>
                <input type="number" required class="form-control" name="estoqueProduto" 
                id="estoqueProduto" placeholder="Quantidade" value="<?php echo e($produt->estoque); ?>"><br>
                <label for="precoProduto">Preço</label>
                <input type="number" required class="form-control" name="precoProduto" 
                id="precoProduto" placeholder="Preço unitário" value="<?php echo e($produt->preco); ?>"><br>
@//if(count($cats)>0)
                <label for="categoriaProduto">Categoria</label>
                <select class="custom-select mr-sm-2" id="categoriaProduto"
                name="categoriaProduto">
@//foreach ($cats as $cat)
                    <option selected>Escolher a categoria</option>
                    <option value="1">Um</option>
                    <option value="2">Dois</option>
                    <option value="3">Três</option>
@//endforeach

                  </select>
@//endif
                <!--<input type="text" class="form-control" name="categoriaProduto" 
                id="categoriaProduto" placeholder="Categoria">-->
            

            </div>
            <button type="submit" class="btn btn-primary btn-sm">Salvar</button>
            <button type="cancel" class="btn btn-danger btn-sm">Cancelar</button>
        </form>
        
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app',["current"=>"produtos"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Master\Documents\Linguagens de programação\laravel\projetos\curso-laravel-5_8\cadastro\resources\views/editarproduto.blade.php ENDPATH**/ ?>