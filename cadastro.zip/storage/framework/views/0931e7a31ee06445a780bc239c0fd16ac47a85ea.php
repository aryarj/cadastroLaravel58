<?php $__env->startSection('body'); ?>
<div class="card border">
    <div class="card-body">
        <h4>Cadastro de Produtos</h4>
<?php if(count($produts)>0): ?>
            <table class="table table-ordered table-hover">
                <thead>
                    <tr>
                        <th>Código</th>
                        <th>Nome do produto</th>
                        <th>Em estoque</th>
                        <th>Preço</th>
                        <th>Ações</th>
                    </tr>
                    <tbody>
<?php $__currentLoopData = $produts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($produt->id); ?></td>
                            <td><?php echo e($produt->nome); ?></td>
                            <td><?php echo e($produt->estoque); ?></td>
                            <td><?php echo e($produt->preco); ?></td>
                            <td>
                                <a href="/produtos/editar/<?php echo e($produt->id); ?>" class="btn btn-sm btn-primary">Editar</a>
                                <a href="/produtos/apagar/<?php echo e($produt->id); ?>" class="btn btn-sm btn-danger">Apagar</a>
                            </td>
                        </tr>
    
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </thead>
            </table>
<?php endif; ?>
    </div>
    <div class="card-footer">
        <a href="/produtos/novo" class="btn btn-sm btn-primary" role="button">Novo Produto</a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app',["current"=>"produtos"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Master\Documents\Linguagens de programação\laravel\projetos\curso-laravel-5_8\cadastro\resources\views/produtos.blade.php ENDPATH**/ ?>