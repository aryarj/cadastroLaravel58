@extends('layout.app',["current"=>"produtos"])

@section('body')
<div class="card border">
    <div class="card-body">
        <form action="/produtos/{{$produt->id}}" method="POST">
            @csrf
            <div class="form-group">
                <label for="nomeProduto">Nome do Produto</label>
                <input type="text" required class="form-control" name="nomeProduto" 
                id="nomeProduto" placeholder="Produto" value="{{$produt->nome}}"><br>
                <label for="estoqueProduto">Em estoque</label>
                <input type="number" required class="form-control" name="estoqueProduto" 
                id="estoqueProduto" placeholder="Quantidade" value="{{$produt->estoque}}"><br>
                <label for="precoProduto">Preço</label>
                <input type="number" required class="form-control" name="precoProduto" 
                id="precoProduto" placeholder="Preço unitário" value="{{$produt->preco}}"><br>
@//if(count($cats)>0)
                <label for="categoriaProduto">Categoria</label>
                <select class="custom-select mr-sm-2" id="categoriaProduto"
                name="categoriaProduto">
@//foreach ($cats as $cat)
                    <option selected>Escolher a categoria</option>
                    <option value="1">Um</option>
                    <option value="2">Dois</option>
                    <option value="3">Três</option>
@//endforeach

                  </select>
@//endif
                <!--<input type="text" class="form-control" name="categoriaProduto" 
                id="categoriaProduto" placeholder="Categoria">-->
            

            </div>
            <button type="submit" class="btn btn-primary btn-sm">Salvar</button>
            <button type="cancel" class="btn btn-danger btn-sm">Cancelar</button>
        </form>
        
    </div>

</div>
@endsection