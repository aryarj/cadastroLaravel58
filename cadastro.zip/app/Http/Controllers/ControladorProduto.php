<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Produto;
use App\Categoria;

class ControladorProduto extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $produts=Produto::all();
        return view('produtos', compact('produts'));
    }

    public function index2()
    {
        $cats=Categoria::all();
        return view('novoproduto',compact('cats'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('novoproduto');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $produt= new Produto();
        $produt->nome= $request->input('nomeProduto');
        $produt->estoque= $request->input('estoqueProduto');
        $produt->preco= $request->input('precoProduto');
        $produt->categoria_id= $request->input('categoriaProduto');
        $produt->save();
        return redirect('/produtos');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $produt = Produto::find($id);
        if(isset($produt))
        {
            return view('editarproduto',compact('produt'));
        }
        return redirect('/produtos');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $produt = Produto::find($id);
        if(isset($produt))
        {
            $produt->nome= $request->input('nomeProduto');
            $produt->estoque= $request->input('estoqueProduto');
            $produt->preco= $request->input('precoProduto');
            $produt->categoria_id= $request->input('categoriaProduto');
            $produt->save();
        }
        return redirect('/produtos');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $produt = Produto::find($id);
        if(isset($produt))
        {
            $produt->delete();
            return redirect('/produtos');
        }
    }
}
